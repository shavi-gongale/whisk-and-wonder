import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Heart, ShoppingCart, Star, Search, Moon, Sun,
  ChevronLeft, ChevronRight, Mail, MapPin, Gift,
  Coffee, Menu, X, Check,
} from "lucide-react";

// ─── Palette ────────────────────────────────────────────────────────────────
const C = {
  crema:      "#FAF6F0",
  oats:       "#F2EBE0",
  apricot:    "#FFBC8A",
  peach:      "#F4956A",
  lilac:      "#C9B4E8",
  lavender:   "#B8A6D8",
  cocoa:      "#4A3728",
  hazelnut:   "#7A5C3A",
  mint:       "#9DD4B8",
  shortbread: "#E0CEB4",
};

// ─── Helpers ────────────────────────────────────────────────────────────────
const serif  = "'Playfair Display', Georgia, serif";
const sans   = "'Poppins', system-ui, sans-serif";
const img    = (id: string, w = 400, h = 400) =>
  `https://images.unsplash.com/photo-${id}?w=${w}&h=${h}&fit=crop&auto=format`;

type Stage = "loading" | "entrance" | "main";

// ─── LOADING SCREEN ─────────────────────────────────────────────────────────
function LoadingScreen({ onDone }: { onDone: () => void }) {
  const [pct, setPct] = useState(0);
  useEffect(() => {
    const t = setInterval(() => {
      setPct(p => {
        const n = p + Math.random() * 3.5 + 1;
        if (n >= 100) { clearInterval(t); setTimeout(onDone, 700); return 100; }
        return n;
      });
    }, 55);
    return () => clearInterval(t);
  }, [onDone]);
  const n = Math.min(Math.round(pct), 100);

  return (
    <motion.div
      className="fixed inset-0 flex flex-col items-center justify-center z-50 overflow-hidden"
      style={{ background: C.crema }}
      exit={{ opacity: 0, scale: 1.03 }}
      transition={{ duration: 0.75 }}
    >
      {/* Floating flour particles */}
      {Array.from({ length: 16 }).map((_, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full pointer-events-none"
          style={{
            width: 3 + (i % 5) * 3,
            height: 3 + (i % 5) * 3,
            background: C.shortbread,
            left: `${(i * 6.5) % 100}%`,
            bottom: -10,
          }}
          animate={{ y: [-10, -300 - i * 15], opacity: [0, 0.55, 0] }}
          transition={{ duration: 3.5 + i * 0.25, delay: i * 0.18, repeat: Infinity, ease: "easeOut" }}
        />
      ))}

      {/* Animated whisk */}
      <motion.div
        animate={{ rotate: [0, 20, -20, 14, -14, 0] }}
        transition={{ duration: 1.6, repeat: Infinity, ease: "easeInOut" }}
        style={{ fontSize: 76, marginBottom: 20 }}
      >🥄</motion.div>

      {/* Brand name */}
      <motion.div
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="text-center mb-3"
      >
        <h1 style={{ fontFamily: serif, color: C.hazelnut, fontSize: "2.8rem", fontWeight: 700, letterSpacing: "-0.01em", lineHeight: 1.1 }}>
          Whisk & Wonder
        </h1>
        <p style={{ color: C.peach, fontFamily: sans, fontSize: "0.65rem", letterSpacing: "0.32em", fontWeight: 600, marginTop: 6 }}>
          ARTISAN BAKERY
        </p>
      </motion.div>

      <motion.p
        animate={{ opacity: [0.45, 1, 0.45] }}
        transition={{ duration: 2, repeat: Infinity }}
        style={{ color: C.hazelnut, fontFamily: sans, fontSize: "0.88rem", marginBottom: "2.5rem", opacity: 0.65 }}
      >
        Preparing something sweet…
      </motion.p>

      {/* Progress */}
      <div style={{ width: 190, height: 2, background: C.shortbread, borderRadius: 2, overflow: "hidden" }}>
        <motion.div
          style={{ height: "100%", background: `linear-gradient(90deg, ${C.apricot}, ${C.peach})`, borderRadius: 2 }}
          animate={{ width: `${n}%` }}
          transition={{ ease: "easeOut", duration: 0.2 }}
        />
      </div>
      <p style={{ marginTop: 10, color: C.lavender, fontFamily: sans, fontSize: "0.72rem" }}>{n}%</p>
    </motion.div>
  );
}

// ─── BAKERY WINDOW ───────────────────────────────────────────────────────────
function BakeryWindow({ items }: { items: string }) {
  return (
    <div style={{
      width: 118, height: 140,
      background: "linear-gradient(150deg, #FFF8E8, #FFECC0, #FFD88A)",
      border: `3px solid ${C.hazelnut}`, borderRadius: 4,
      position: "relative", overflow: "hidden", flexShrink: 0,
    }}>
      <div style={{ position: "absolute", inset: 0, background: "rgba(255,190,80,0.22)" }} />
      <div style={{ position: "absolute", left: "50%", top: 0, bottom: 0, width: 2, background: "rgba(122,92,58,0.35)" }} />
      <div style={{ position: "absolute", top: "38%", left: 0, right: 0, height: 2, background: "rgba(122,92,58,0.35)" }} />
      <div style={{ position: "absolute", bottom: 7, left: 0, right: 0, display: "flex", justifyContent: "center", gap: 4, fontSize: "1.15rem" }}>
        {items}
      </div>
      {/* warm glow */}
      <div style={{ position: "absolute", inset: 0, boxShadow: "inset 0 0 20px rgba(255,200,80,0.35)" }} />
    </div>
  );
}

// ─── ENTRANCE SCREEN ─────────────────────────────────────────────────────────
function EntranceScreen({ onEnter, dark }: { onEnter: () => void; dark: boolean }) {
  return (
    <motion.div
      className="fixed inset-0 flex flex-col items-center justify-center z-40 overflow-hidden"
      style={{ background: dark ? "linear-gradient(180deg, #1A2A34 0%, #1E1812 60%, #2A1F18 100%)" : "linear-gradient(180deg, #C8E8F2 0%, #E0F0EC 28%, #FAF6F0 65%, #F2EBE0 100%)" }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.65 }}
    >
      {/* Sun / Moon */}
      <motion.div
        className="absolute top-8 right-24"
        animate={{ scale: [1, 1.05, 1] }}
        transition={{ duration: 4, repeat: Infinity }}
        style={{
          width: 56, height: 56, borderRadius: "50%",
          background: dark ? "radial-gradient(circle, #C8D8FF, #8AA8FF)" : "radial-gradient(circle, #FFE8A0, #FFD060)",
          boxShadow: dark ? "0 0 40px 12px rgba(140,160,255,0.35)" : "0 0 44px 12px rgba(255,210,90,0.45)",
        }}
      />

      {/* Clouds */}
      {[{ top: 44, left: 50, w: 88, op: 0.9 }, { top: 20, left: 230, w: 60, op: 0.7 }, { top: 66, right: 70, w: 72, op: 0.8 }].map((cl, i) => (
        <motion.div key={i} className="absolute" style={{ top: cl.top, left: (cl as any).left, right: (cl as any).right, opacity: dark ? cl.op * 0.25 : cl.op }}
          animate={{ x: [0, 10, 0] }} transition={{ duration: 9 + i * 2, repeat: Infinity, ease: "easeInOut" }}>
          <div style={{ width: cl.w, height: cl.w * 0.34, background: dark ? "#3A4A60" : "#fff", borderRadius: 100, boxShadow: `${cl.w * 0.22}px 5px 0 ${cl.w * 0.11}px ${dark ? "#3A4A60" : "#fff"}, -${cl.w * 0.11}px 5px 0 ${cl.w * 0.055}px ${dark ? "#3A4A60" : "#fff"}` }} />
        </motion.div>
      ))}

      {/* Stars (dark mode) */}
      {dark && Array.from({ length: 12 }).map((_, i) => (
        <motion.div key={i} className="absolute" style={{ top: `${5 + (i * 7) % 30}%`, left: `${(i * 8.3) % 90}%`, width: 3, height: 3, borderRadius: "50%", background: "#fff" }}
          animate={{ opacity: [0.2, 1, 0.2] }} transition={{ duration: 2 + i * 0.3, repeat: Infinity, delay: i * 0.2 }} />
      ))}

      {/* Building */}
      <div className="relative" style={{ marginTop: 20 }}>
        {/* Awning */}
        <div style={{
          width: 400, height: 56,
          background: dark ? "linear-gradient(135deg, #3A2A1E, #2A1810)" : "linear-gradient(135deg, #8B6347, #5C3D2E)",
          borderRadius: "12px 12px 0 0",
          display: "flex", alignItems: "center", justifyContent: "center",
          boxShadow: "0 6px 28px rgba(0,0,0,0.25)",
        }}>
          <span style={{ color: C.apricot, fontFamily: serif, fontSize: "1.2rem", fontWeight: 600 }}>
            ✦  Whisk & Wonder  ✦
          </span>
        </div>

        {/* Facade */}
        <div style={{
          width: 400,
          background: dark ? "#3A2A1E" : C.oats,
          border: `2px solid ${dark ? "rgba(255,255,255,0.1)" : C.shortbread}`, borderTop: "none",
          display: "flex", alignItems: "flex-end", padding: "16px 14px 0", gap: 10,
        }}>
          <BakeryWindow items="🎂🍰" />

          {/* Door */}
          <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center" }}>
            <div style={{
              width: 88, height: 158,
              background: dark ? "linear-gradient(180deg, #5C3D2E, #2A1810)" : "linear-gradient(180deg, #8B6347, #4A3728)",
              borderRadius: "44px 44px 0 0",
              border: `3px solid ${dark ? "#1A0E08" : "#3A2818"}`,
              position: "relative",
              display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 10,
            }}>
              <div style={{ width: 46, height: 46, borderRadius: "50%", background: "radial-gradient(circle at 35% 35%, #FFF8DC, #FFD060)", border: `2px solid ${C.apricot}`, boxShadow: "0 0 18px rgba(255,200,70,0.6)" }} />
              <div style={{ background: C.mint, color: "#1A4A34", padding: "3px 10px", borderRadius: 20, fontSize: "0.52rem", fontFamily: sans, fontWeight: 700, letterSpacing: "0.14em" }}>
                OPEN
              </div>
              <div style={{ position: "absolute", right: 10, top: "55%", width: 8, height: 8, background: C.apricot, borderRadius: "50%" }} />
            </div>
          </div>

          <BakeryWindow items="🍩🧁" />
        </div>

        {/* Step */}
        <div style={{ width: 400, height: 16, background: dark ? "#1A1008" : "linear-gradient(180deg, #C8B898, #B8A880)", borderRadius: "0 0 6px 6px" }} />

        {/* Ground décor */}
        {[{ s: "🌸", b: -32, l: -64, fs: 26 }, { s: "🌿", b: -18, l: -36, fs: 22 }, { s: "🌺", b: -32, r: -72, fs: 26 }, { s: "🌿", b: -18, r: -38, fs: 22 }].map((d, i) => (
          <div key={i} className="absolute" style={{ bottom: d.b, left: (d as any).l, right: (d as any).r, fontSize: d.fs }} >{d.s}</div>
        ))}

        {/* Sleeping cat */}
        <motion.div className="absolute" style={{ bottom: -44, left: "50%", transform: "translateX(-50%)", fontSize: "1.9rem" }}
          animate={{ scale: [1, 1.05, 1] }} transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut" }}>
          😺
        </motion.div>

        {/* Bicycle */}
        <div className="absolute" style={{ bottom: -28, right: -120, fontSize: "2.3rem" }}>🚲</div>

        {/* Sparkles */}
        {["✨", "✦", "⭐"].map((s, i) => (
          <motion.span key={i} className="absolute" style={{ fontSize: "1.1rem", color: C.lilac, top: i * 40 - 20, ...(i % 2 === 0 ? { left: -52 } : { right: -44 }) }}
            animate={{ opacity: [0.3, 1, 0.3], scale: [0.8, 1.3, 0.8] }}
            transition={{ duration: 2 + i * 0.7, repeat: Infinity, delay: i * 0.4 }}>
            {s}
          </motion.span>
        ))}
      </div>

      {/* CTA */}
      <motion.button
        onClick={onEnter}
        initial={{ opacity: 0, y: 22 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.45 }}
        whileHover={{ scale: 1.05, boxShadow: "0 16px 48px rgba(122,92,58,0.5)" }}
        whileTap={{ scale: 0.97 }}
        style={{
          marginTop: 64, padding: "16px 56px",
          background: dark ? C.apricot : C.hazelnut,
          color: dark ? C.cocoa : C.crema,
          border: "none", borderRadius: 50,
          fontFamily: sans, fontWeight: 600, fontSize: "0.96rem", letterSpacing: "0.04em",
          cursor: "pointer", boxShadow: "0 8px 34px rgba(122,92,58,0.35)",
        }}
      >
        Enter Bakery ✨
      </motion.button>

      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.7 }}
        style={{ marginTop: 14, color: C.lavender, fontFamily: sans, fontSize: "0.78rem" }}>
        Step inside and discover the magic
      </motion.p>
    </motion.div>
  );
}

// ─── NAVBAR ──────────────────────────────────────────────────────────────────
const navLinks = ["Home", "Menu", "Custom Cakes", "Best Sellers", "Gallery", "Our Story"];

function Navbar({ dark, setDark, cartCount }: { dark: boolean; setDark: (v: boolean) => void; cartCount: number }) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", h);
    return () => window.removeEventListener("scroll", h);
  }, []);

  const glass = scrolled
    ? `${dark ? "rgba(42,31,24,0.82)" : "rgba(250,246,240,0.82)"} backdrop-blur-xl`
    : "transparent";

  return (
    <header
      className="fixed top-0 left-0 right-0 z-30 transition-all duration-500"
      style={{
        background: scrolled ? (dark ? "rgba(42,31,24,0.82)" : "rgba(250,246,240,0.88)") : "transparent",
        backdropFilter: scrolled ? "blur(20px)" : "none",
        borderBottom: scrolled ? `1px solid ${dark ? "rgba(255,255,255,0.08)" : C.shortbread}` : "none",
        padding: "0 max(24px, calc((100vw - 1440px) / 2 + 24px))",
      }}
    >
      <nav className="flex items-center justify-between h-16 max-w-[1440px] mx-auto">
        {/* Logo */}
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ fontSize: "1.6rem" }}>🥐</span>
          <span style={{ fontFamily: serif, fontWeight: 700, fontSize: "1.25rem", color: dark ? C.apricot : C.hazelnut }}>
            Whisk & Wonder
          </span>
        </div>

        {/* Desktop links */}
        <div className="hidden md:flex items-center gap-7">
          {navLinks.map(link => (
            <button key={link} onClick={() => { const id = link.toLowerCase().replace(/\s+/g, "-"); document.getElementById(id)?.scrollIntoView({ behavior: "smooth" }); }}
              style={{ fontFamily: sans, fontSize: "0.82rem", fontWeight: 500, color: dark ? C.oats : C.cocoa, background: "none", border: "none", cursor: "pointer", opacity: 0.8, transition: "opacity 0.2s" }}
              onMouseEnter={e => (e.currentTarget.style.opacity = "1")}
              onMouseLeave={e => (e.currentTarget.style.opacity = "0.8")}
            >{link}</button>
          ))}
        </div>

        {/* Icons */}
        <div className="flex items-center gap-3">
          <IconBtn icon={<Search size={17} />} dark={dark} />
          <IconBtn icon={<Heart size={17} />} dark={dark} />
          <div className="relative">
            <IconBtn icon={<ShoppingCart size={17} />} dark={dark} />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-bold"
                style={{ background: C.peach, color: "#fff", fontFamily: sans }}>{cartCount}</span>
            )}
          </div>
          <button onClick={() => setDark(!dark)} className="p-2 rounded-full transition-colors"
            style={{ background: dark ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.05)", border: "none", cursor: "pointer", color: dark ? C.apricot : C.hazelnut }}>
            {dark ? <Sun size={17} /> : <Moon size={17} />}
          </button>
          <button className="md:hidden p-2" style={{ background: "none", border: "none", cursor: "pointer", color: dark ? C.crema : C.cocoa }}
            onClick={() => setMobileOpen(v => !v)}>
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            className="md:hidden overflow-hidden" style={{ background: dark ? "rgba(42,31,24,0.96)" : "rgba(250,246,240,0.96)", borderTop: `1px solid ${C.shortbread}` }}>
            {navLinks.map(l => (
              <button key={l} onClick={() => { setMobileOpen(false); document.getElementById(l.toLowerCase().replace(/\s+/g, "-"))?.scrollIntoView({ behavior: "smooth" }); }}
                className="block w-full text-left px-6 py-3" style={{ fontFamily: sans, fontSize: "0.9rem", color: dark ? C.oats : C.cocoa, background: "none", border: "none", cursor: "pointer" }}>
                {l}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

function IconBtn({ icon, dark }: { icon: React.ReactNode; dark: boolean }) {
  return (
    <button className="p-2 rounded-full transition-all"
      style={{ background: "none", border: "none", cursor: "pointer", color: dark ? C.oats : C.cocoa, opacity: 0.75 }}
      onMouseEnter={e => (e.currentTarget.style.opacity = "1")}
      onMouseLeave={e => (e.currentTarget.style.opacity = "0.75")}>
      {icon}
    </button>
  );
}

// ─── HERO SECTION ─────────────────────────────────────────────────────────────
const floatingItems = ["🍓", "🍩", "🧁", "🍪", "🥐", "🍫", "🌸", "🍋", "✨", "🫐"];

function HeroSection({ dark }: { dark: boolean }) {
  return (
    <section id="home" className="relative min-h-screen flex items-center overflow-hidden" style={{ background: dark ? C.cocoa : undefined }}>
      {/* Background image */}
      <div className="absolute inset-0">
        <img
          src={img("1602663491496-73f07481dbea", 1440, 900)}
          alt="Luxury bakery interior"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0" style={{ background: dark ? "rgba(42,31,24,0.75)" : "rgba(250,246,240,0.72)" }} />
        <div className="absolute inset-0" style={{ background: `radial-gradient(ellipse at 50% 60%, transparent 30%, ${dark ? "rgba(42,31,24,0.6)" : "rgba(250,246,240,0.5)"} 100%)` }} />
      </div>

      {/* Floating food items */}
      {floatingItems.map((item, i) => (
        <motion.div
          key={i}
          className="absolute pointer-events-none select-none"
          style={{
            left: `${8 + (i * 9.3) % 84}%`,
            top: `${12 + (i * 11.7) % 70}%`,
            fontSize: `${1.2 + (i % 4) * 0.4}rem`,
            opacity: 0.6,
          }}
          animate={{ y: [0, -16, 0], rotate: [0, 8, -8, 0], scale: [1, 1.08, 1] }}
          transition={{ duration: 3 + i * 0.4, repeat: Infinity, ease: "easeInOut", delay: i * 0.3 }}
        >
          {item}
        </motion.div>
      ))}

      {/* Content */}
      <div className="relative z-10 max-w-[1440px] mx-auto px-6 w-full flex flex-col items-center text-center pt-24 pb-16">
        {/* Badge */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="flex items-center gap-2 px-5 py-2 rounded-full mb-8"
          style={{ background: dark ? "rgba(255,188,138,0.15)" : "rgba(244,149,106,0.12)", border: `1px solid ${dark ? "rgba(255,188,138,0.3)" : "rgba(244,149,106,0.3)"}` }}>
          <span style={{ fontSize: "0.9rem" }}>✦</span>
          <span style={{ fontFamily: sans, fontSize: "0.72rem", fontWeight: 600, color: dark ? C.apricot : C.peach, letterSpacing: "0.22em" }}>
            FRESHLY BAKED DAILY
          </span>
          <span style={{ fontSize: "0.9rem" }}>✦</span>
        </motion.div>

        {/* Heading */}
        <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}
          style={{ fontFamily: serif, fontWeight: 700, fontSize: "clamp(2.8rem, 6vw, 5rem)", color: dark ? C.crema : C.cocoa, lineHeight: 1.12, maxWidth: 780, marginBottom: "1.4rem" }}>
          Freshly Baked{" "}
          <em style={{ fontStyle: "italic", color: dark ? C.apricot : C.hazelnut }}>Happiness</em>{" "}
          Every Day
        </motion.h1>

        {/* Subheading */}
        <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}
          style={{ fontFamily: sans, fontSize: "1.05rem", color: dark ? C.shortbread : C.hazelnut, maxWidth: 540, lineHeight: 1.75, marginBottom: "2.8rem", fontWeight: 300, opacity: 0.85 }}>
          Handcrafted desserts made with premium ingredients, baked fresh every morning with love and a little magic.
        </motion.p>

        {/* CTAs */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.65 }}
          className="flex flex-wrap gap-4 justify-center">
          <Btn variant="primary" dark={dark} onClick={() => document.getElementById("menu")?.scrollIntoView({ behavior: "smooth" })}>
            Explore Menu
          </Btn>
          <Btn variant="ghost" dark={dark} onClick={() => {}}>
            Order Now
          </Btn>
        </motion.div>

        {/* Stats */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.85 }}
          className="flex gap-12 mt-16 flex-wrap justify-center">
          {[["12k+", "Happy Customers"], ["48+", "Signature Recipes"], ["100%", "Fresh Daily"]].map(([num, label]) => (
            <div key={num} className="text-center">
              <p style={{ fontFamily: serif, fontSize: "2rem", fontWeight: 700, color: dark ? C.apricot : C.peach, lineHeight: 1 }}>{num}</p>
              <p style={{ fontFamily: sans, fontSize: "0.72rem", color: dark ? C.shortbread : C.hazelnut, marginTop: 4, letterSpacing: "0.06em", opacity: 0.8 }}>{label}</p>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div className="absolute bottom-8 left-1/2 -translate-x-1/2"
        animate={{ y: [0, 8, 0] }} transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}>
        <div style={{ width: 28, height: 44, border: `2px solid ${dark ? C.shortbread : C.shortbread}`, borderRadius: 20, opacity: 0.5, display: "flex", justifyContent: "center", paddingTop: 6 }}>
          <motion.div style={{ width: 3, height: 8, background: dark ? C.apricot : C.peach, borderRadius: 2 }}
            animate={{ y: [0, 12, 0], opacity: [1, 0, 1] }} transition={{ duration: 2, repeat: Infinity }} />
        </div>
      </motion.div>
    </section>
  );
}

// ─── BUTTON ──────────────────────────────────────────────────────────────────
function Btn({ children, variant = "primary", dark, onClick }: {
  children: React.ReactNode; variant?: "primary" | "ghost"; dark: boolean; onClick?: () => void;
}) {
  const isPrimary = variant === "primary";
  return (
    <motion.button
      onClick={onClick}
      whileHover={{ scale: 1.04 }}
      whileTap={{ scale: 0.97 }}
      style={{
        padding: "14px 40px",
        background: isPrimary ? (dark ? C.apricot : C.hazelnut) : "transparent",
        color: isPrimary ? (dark ? C.cocoa : C.crema) : (dark ? C.apricot : C.hazelnut),
        border: isPrimary ? "none" : `2px solid ${dark ? C.apricot : C.hazelnut}`,
        borderRadius: 50,
        fontFamily: sans, fontWeight: 600, fontSize: "0.88rem", letterSpacing: "0.03em",
        cursor: "pointer",
        boxShadow: isPrimary ? `0 8px 28px rgba(122,92,58,0.3)` : "none",
      }}
    >{children}</motion.button>
  );
}

// ─── CATEGORIES SECTION ───────────────────────────────────────────────────────
const categories = [
  { label: "Cakes", emoji: "🎂" }, { label: "Cupcakes", emoji: "🧁" }, { label: "Cookies", emoji: "🍪" },
  { label: "Donuts", emoji: "🍩" }, { label: "Pastries", emoji: "🥐" }, { label: "Macarons", emoji: "🫐" },
  { label: "Coffee", emoji: "☕" }, { label: "Bread", emoji: "🍞" }, { label: "Chocolate", emoji: "🍫" },
  { label: "Seasonal", emoji: "🌸" },
];

function CategoriesSection({ dark }: { dark: boolean }) {
  const [active, setActive] = useState("Cakes");
  return (
    <section id="menu" style={{ background: dark ? "#221810" : C.oats, padding: "100px 24px" }}>
      <div className="max-w-[1440px] mx-auto">
        <SectionLabel dark={dark}>Our Menu</SectionLabel>
        <h2 style={{ fontFamily: serif, fontSize: "clamp(2rem, 4vw, 3rem)", color: dark ? C.crema : C.cocoa, marginBottom: "3.5rem", fontWeight: 700 }}>
          What are you <em style={{ fontStyle: "italic", color: dark ? C.apricot : C.peach }}>craving</em> today?
        </h2>
        <div className="flex flex-wrap gap-4 justify-center">
          {categories.map((c, i) => (
            <motion.button
              key={c.label}
              onClick={() => setActive(c.label)}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              whileHover={{ scale: 1.07, y: -4 }}
              whileTap={{ scale: 0.96 }}
              style={{
                display: "flex", flexDirection: "column", alignItems: "center", gap: 8,
                padding: "20px 24px", borderRadius: 28,
                background: active === c.label ? (dark ? C.apricot : C.hazelnut) : (dark ? "rgba(255,255,255,0.06)" : C.crema),
                border: `2px solid ${active === c.label ? "transparent" : dark ? "rgba(255,255,255,0.1)" : C.shortbread}`,
                cursor: "pointer",
                boxShadow: active === c.label ? `0 8px 28px rgba(122,92,58,0.3)` : "0 2px 12px rgba(0,0,0,0.05)",
                transition: "all 0.25s ease",
                minWidth: 96,
              }}
            >
              <span style={{ fontSize: "2rem" }}>{c.emoji}</span>
              <span style={{ fontFamily: sans, fontSize: "0.75rem", fontWeight: 600, color: active === c.label ? (dark ? C.cocoa : C.crema) : (dark ? C.oats : C.hazelnut), letterSpacing: "0.04em" }}>
                {c.label}
              </span>
            </motion.button>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── FEATURED PRODUCTS ────────────────────────────────────────────────────────
const products = [
  { name: "Strawberry Dream Cake", desc: "Three layers of vanilla sponge with fresh strawberry compote & whipped cream", price: "$48", rating: 5, tag: "Bestseller", imgId: "1602663491496-73f07481dbea" },
  { name: "Butter Croissant", desc: "Flaky, golden layers of pure butter pastry, baked to perfection each morning", price: "$6", rating: 5, tag: "Daily Fresh", imgId: "1555507036-ab1f4038808a" },
  { name: "Pastel Macarons Box", desc: "Assorted French macarons in seasonal flavors — rose, pistachio, lemon & lavender", price: "$24", rating: 5, tag: "Gift Worthy", imgId: "1634118520179-0c78b72df69a" },
  { name: "Glazed Donut Tower", desc: "Hand-glazed donuts in rotating seasonal flavors with artisan sprinkle toppings", price: "$14", rating: 4, tag: "Popular", imgId: "1514517521153-1be72277b32f" },
];

function ProductCard({ p, dark }: { p: typeof products[0]; dark: boolean }) {
  const [liked, setLiked] = useState(false);
  const [added, setAdded] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      whileHover={{ y: -10, boxShadow: `0 28px 60px rgba(0,0,0,${dark ? 0.35 : 0.14})` }}
      transition={{ duration: 0.35 }}
      style={{
        background: dark ? "#3A2A1E" : C.crema,
        borderRadius: 28,
        overflow: "hidden",
        border: `1px solid ${dark ? "rgba(255,255,255,0.08)" : C.shortbread}`,
        boxShadow: `0 8px 32px rgba(0,0,0,${dark ? 0.25 : 0.07})`,
        flex: "1 1 280px",
        maxWidth: 320,
        cursor: "pointer",
      }}
    >
      {/* Image */}
      <div className="relative overflow-hidden" style={{ height: 220 }}>
        <motion.img
          src={img(p.imgId, 400, 300)}
          alt={p.name}
          className="w-full h-full object-cover"
          whileHover={{ scale: 1.08 }}
          transition={{ duration: 0.5 }}
        />
        <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(0,0,0,0.25) 0%, transparent 50%)" }} />

        {/* Tag */}
        <div className="absolute top-3 left-3">
          <span style={{ background: C.peach, color: "#fff", fontFamily: sans, fontSize: "0.62rem", fontWeight: 700, letterSpacing: "0.1em", padding: "4px 12px", borderRadius: 20 }}>
            {p.tag}
          </span>
        </div>

        {/* Like */}
        <button
          onClick={e => { e.stopPropagation(); setLiked(!liked); }}
          className="absolute top-3 right-3 w-9 h-9 rounded-full flex items-center justify-center"
          style={{ background: "rgba(255,255,255,0.9)", border: "none", cursor: "pointer" }}>
          <Heart size={16} fill={liked ? C.peach : "none"} color={liked ? C.peach : C.cocoa} />
        </button>
      </div>

      {/* Body */}
      <div style={{ padding: "20px 22px 22px" }}>
        <div className="flex items-center gap-1 mb-2">
          {Array.from({ length: 5 }).map((_, i) => (
            <Star key={i} size={11} fill={i < p.rating ? C.apricot : "none"} color={i < p.rating ? C.apricot : C.shortbread} />
          ))}
        </div>
        <h3 style={{ fontFamily: serif, fontSize: "1.1rem", fontWeight: 700, color: dark ? C.crema : C.cocoa, marginBottom: 6, lineHeight: 1.3 }}>{p.name}</h3>
        <p style={{ fontFamily: sans, fontSize: "0.78rem", color: dark ? C.shortbread : C.hazelnut, lineHeight: 1.7, opacity: 0.8, marginBottom: 16 }}>{p.desc}</p>

        <div className="flex items-center justify-between">
          <span style={{ fontFamily: serif, fontSize: "1.35rem", fontWeight: 700, color: dark ? C.apricot : C.peach }}>{p.price}</span>
          <motion.button
            onClick={() => { setAdded(true); setTimeout(() => setAdded(false), 1500); }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.96 }}
            style={{
              padding: "9px 20px", borderRadius: 50,
              background: added ? C.mint : (dark ? C.apricot : C.hazelnut),
              color: added ? "#1A4A34" : (dark ? C.cocoa : C.crema),
              border: "none", cursor: "pointer",
              fontFamily: sans, fontSize: "0.77rem", fontWeight: 600, letterSpacing: "0.03em",
              display: "flex", alignItems: "center", gap: 6,
              transition: "background 0.3s, color 0.3s",
            }}>
            {added ? <><Check size={13} /> Added!</> : <><ShoppingCart size={13} /> Add to Cart</>}
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
}

function FeaturedProducts({ dark }: { dark: boolean }) {
  return (
    <section style={{ background: dark ? "#2A1F18" : C.crema, padding: "100px 24px" }}>
      <div className="max-w-[1440px] mx-auto">
        <SectionLabel dark={dark}>Featured</SectionLabel>
        <div className="flex items-end justify-between mb-12 flex-wrap gap-4">
          <h2 style={{ fontFamily: serif, fontSize: "clamp(2rem, 4vw, 3rem)", color: dark ? C.crema : C.cocoa, fontWeight: 700, maxWidth: 480 }}>
            Our most <em style={{ fontStyle: "italic", color: dark ? C.apricot : C.peach }}>loved</em> creations
          </h2>
          <button style={{ fontFamily: sans, fontSize: "0.83rem", fontWeight: 600, color: dark ? C.apricot : C.hazelnut, background: "none", border: `1px solid ${dark ? C.apricot : C.hazelnut}`, borderRadius: 50, padding: "9px 24px", cursor: "pointer" }}>
            View All →
          </button>
        </div>
        <div className="flex flex-wrap gap-6 justify-center">
          {products.map(p => <ProductCard key={p.name} p={p} dark={dark} />)}
        </div>
      </div>
    </section>
  );
}

// ─── CAKE BUILDER ─────────────────────────────────────────────────────────────
const builderOptions = {
  shape:   ["Round", "Square", "Heart"],
  size:    ["6 inch", "8 inch", "10 inch"],
  flavor:  ["Vanilla", "Chocolate", "Strawberry", "Lemon"],
  cream:   ["Buttercream", "Whipped", "Ganache"],
  color:   [C.crema, "#F4B8C8", "#C9B4E8", "#9DD4B8", "#FFBC8A", "#7A5C3A"],
  toppings: ["🍓 Strawberries", "🫐 Blueberries", "🌸 Flowers", "🍫 Chocolate", "🌟 Sprinkles", "🕯️ Candles"],
};
const flavorColors: Record<string, string> = { Vanilla: "#FFF5DC", Chocolate: "#5C3D2E", Strawberry: "#F4A8C0", Lemon: "#FFF44F" };
const creamColors: Record<string, string> = { Buttercream: "#FFFDE7", Whipped: "#F8F8F8", Ganache: "#3E2012" };

function CakeBuilderSection({ dark }: { dark: boolean }) {
  const [sel, setSel] = useState({ shape: "Round", size: "8 inch", flavor: "Strawberry", cream: "Buttercream", color: "#F4B8C8", toppings: ["🍓 Strawberries", "🌸 Flowers"], message: "Happy Birthday! 🎂" });

  const toggle = (key: "toppings", v: string) => {
    setSel(s => ({ ...s, toppings: s.toppings.includes(v) ? s.toppings.filter(x => x !== v) : [...s.toppings, v] }));
  };

  const sizeMap: Record<string, number> = { "6 inch": 120, "8 inch": 156, "10 inch": 190 };
  const cakeW = sizeMap[sel.size];

  return (
    <section id="custom-cakes" style={{ background: dark ? "#221810" : C.oats, padding: "100px 24px" }}>
      <div className="max-w-[1440px] mx-auto">
        <SectionLabel dark={dark}>Cake Builder</SectionLabel>
        <h2 style={{ fontFamily: serif, fontSize: "clamp(2rem, 4vw, 3rem)", color: dark ? C.crema : C.cocoa, fontWeight: 700, marginBottom: "0.6rem" }}>
          Design your <em style={{ fontStyle: "italic", color: dark ? C.apricot : C.peach }}>dream</em> cake
        </h2>
        <p style={{ fontFamily: sans, fontSize: "0.9rem", color: dark ? C.shortbread : C.hazelnut, marginBottom: "3.5rem", opacity: 0.75 }}>
          Customize every detail and see it come to life instantly.
        </p>

        <div className="flex flex-col lg:flex-row gap-10 items-start">
          {/* Controls */}
          <div className="flex-1 min-w-0 grid gap-7">
            {/* Shape */}
            <BuilderGroup label="Shape" dark={dark}>
              <div className="flex gap-3 flex-wrap">
                {builderOptions.shape.map(v => (
                  <ChipBtn key={v} active={sel.shape === v} dark={dark} onClick={() => setSel(s => ({ ...s, shape: v }))}>{v}</ChipBtn>
                ))}
              </div>
            </BuilderGroup>

            {/* Size */}
            <BuilderGroup label="Size" dark={dark}>
              <div className="flex gap-3 flex-wrap">
                {builderOptions.size.map(v => (
                  <ChipBtn key={v} active={sel.size === v} dark={dark} onClick={() => setSel(s => ({ ...s, size: v }))}>{v}</ChipBtn>
                ))}
              </div>
            </BuilderGroup>

            {/* Flavor + Cream */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-7">
              <BuilderGroup label="Sponge Flavor" dark={dark}>
                <div className="flex gap-2 flex-wrap">
                  {builderOptions.flavor.map(v => (
                    <ChipBtn key={v} active={sel.flavor === v} dark={dark} onClick={() => setSel(s => ({ ...s, flavor: v }))}>{v}</ChipBtn>
                  ))}
                </div>
              </BuilderGroup>
              <BuilderGroup label="Cream Style" dark={dark}>
                <div className="flex gap-2 flex-wrap">
                  {builderOptions.cream.map(v => (
                    <ChipBtn key={v} active={sel.cream === v} dark={dark} onClick={() => setSel(s => ({ ...s, cream: v }))}>{v}</ChipBtn>
                  ))}
                </div>
              </BuilderGroup>
            </div>

            {/* Color */}
            <BuilderGroup label="Frosting Color" dark={dark}>
              <div className="flex gap-3">
                {builderOptions.color.map(v => (
                  <button key={v} onClick={() => setSel(s => ({ ...s, color: v }))}
                    style={{ width: 36, height: 36, borderRadius: "50%", background: v, border: sel.color === v ? `3px solid ${dark ? C.apricot : C.hazelnut}` : "3px solid transparent", cursor: "pointer", boxShadow: "0 2px 8px rgba(0,0,0,0.15)", transition: "border 0.2s" }} />
                ))}
              </div>
            </BuilderGroup>

            {/* Toppings */}
            <BuilderGroup label="Decorations" dark={dark}>
              <div className="flex gap-2 flex-wrap">
                {builderOptions.toppings.map(v => (
                  <ChipBtn key={v} active={sel.toppings.includes(v)} dark={dark} onClick={() => toggle("toppings", v)}>{v}</ChipBtn>
                ))}
              </div>
            </BuilderGroup>

            {/* Message */}
            <BuilderGroup label="Greeting Message" dark={dark}>
              <input
                value={sel.message}
                onChange={e => setSel(s => ({ ...s, message: e.target.value }))}
                maxLength={40}
                placeholder="Happy Birthday! 🎂"
                style={{
                  width: "100%", padding: "11px 18px", borderRadius: 50,
                  background: dark ? "rgba(255,255,255,0.07)" : C.crema,
                  border: `1px solid ${dark ? "rgba(255,255,255,0.15)" : C.shortbread}`,
                  fontFamily: sans, fontSize: "0.88rem", color: dark ? C.crema : C.cocoa,
                  outline: "none",
                }}
              />
            </BuilderGroup>
          </div>

          {/* Live Cake Preview */}
          <div className="lg:w-96 flex-shrink-0 flex flex-col items-center gap-6 sticky top-24">
            <div style={{
              width: "100%", minHeight: 340, borderRadius: 28,
              background: dark ? "#3A2A1E" : C.crema,
              border: `1px solid ${dark ? "rgba(255,255,255,0.08)" : C.shortbread}`,
              display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
              padding: "32px 16px", gap: 8,
            }}>
              <p style={{ fontFamily: sans, fontSize: "0.7rem", color: dark ? C.shortbread : C.hazelnut, letterSpacing: "0.18em", fontWeight: 600, marginBottom: 12 }}>LIVE PREVIEW</p>

              {/* Cake visual */}
              <motion.div layout style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 0 }}
                animate={{ scale: [1, 1.02, 1] }} transition={{ duration: 3, repeat: Infinity }}>
                {/* Candles */}
                {sel.toppings.includes("🕯️ Candles") && (
                  <div className="flex gap-3 mb-1">
                    {["💛", "🩷", "💜"].map(c => <span key={c} style={{ fontSize: "1rem" }}>{c}</span>)}
                  </div>
                )}

                {/* Top tier */}
                <div style={{
                  width: cakeW * 0.62, height: 52,
                  background: sel.color,
                  borderRadius: "50% 50% 0 0 / 20px 20px 0 0",
                  borderTop: `10px solid ${creamColors[sel.cream]}`,
                  boxShadow: `0 -4px 12px rgba(0,0,0,0.1)`,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: "0.9rem",
                }}>
                  {sel.toppings.includes("🌸 Flowers") && "🌸"}
                </div>

                {/* Cream bridge */}
                <div style={{ width: cakeW * 0.72, height: 8, background: creamColors[sel.cream] }} />

                {/* Middle tier */}
                <div style={{
                  width: cakeW * 0.82, height: 64,
                  background: sel.color,
                  borderLeft: `6px solid ${flavorColors[sel.flavor]}22`,
                  borderRight: `6px solid ${flavorColors[sel.flavor]}22`,
                  display: "flex", alignItems: "center", justifyContent: "center", gap: 4, fontSize: "0.9rem",
                }}>
                  {sel.toppings.includes("🍓 Strawberries") && "🍓"}
                  {sel.toppings.includes("🫐 Blueberries") && "🫐"}
                  {sel.toppings.includes("🍫 Chocolate") && "🍫"}
                </div>

                {/* Cream bridge */}
                <div style={{ width: cakeW, height: 8, background: creamColors[sel.cream] }} />

                {/* Bottom tier */}
                <div style={{
                  width: cakeW, height: 72,
                  background: `linear-gradient(135deg, ${flavorColors[sel.flavor]}88, ${sel.color})`,
                  borderRadius: "0 0 14px 14px",
                  boxShadow: "0 12px 32px rgba(0,0,0,0.15)",
                  display: "flex", alignItems: "center", justifyContent: "center", gap: 4, fontSize: "0.85rem",
                }}>
                  {sel.toppings.includes("🌟 Sprinkles") && <span style={{ opacity: 0.8 }}>✨🌟✨</span>}
                </div>

                {/* Plate */}
                <div style={{ width: cakeW + 30, height: 12, background: dark ? "#5C4030" : C.shortbread, borderRadius: "0 0 50% 50% / 0 0 6px 6px" }} />
              </motion.div>

              {/* Message */}
              {sel.message && (
                <motion.div layout
                  style={{ marginTop: 20, padding: "10px 20px", borderRadius: 50, background: `${C.lilac}33`, border: `1px solid ${C.lilac}66` }}>
                  <p style={{ fontFamily: serif, fontStyle: "italic", fontSize: "0.88rem", color: dark ? C.lilac : C.lavender, textAlign: "center" }}>
                    "{sel.message}"
                  </p>
                </motion.div>
              )}

              {/* Size & Flavor labels */}
              <div className="flex gap-3 mt-4 flex-wrap justify-center">
                {[sel.shape, sel.size, sel.flavor, sel.cream].map(l => (
                  <span key={l} style={{ fontFamily: sans, fontSize: "0.68rem", fontWeight: 600, color: dark ? C.apricot : C.peach, background: `${C.peach}18`, padding: "3px 10px", borderRadius: 20, letterSpacing: "0.06em" }}>{l}</span>
                ))}
              </div>
            </div>

            <Btn variant="primary" dark={dark} onClick={() => {}}>
              Add Custom Cake to Cart — $72
            </Btn>
          </div>
        </div>
      </div>
    </section>
  );
}

function BuilderGroup({ label, children, dark }: { label: string; children: React.ReactNode; dark: boolean }) {
  return (
    <div>
      <p style={{ fontFamily: sans, fontSize: "0.72rem", fontWeight: 700, color: dark ? C.shortbread : C.hazelnut, letterSpacing: "0.16em", marginBottom: 12 }}>{label.toUpperCase()}</p>
      {children}
    </div>
  );
}

function ChipBtn({ children, active, dark, onClick }: { children: React.ReactNode; active: boolean; dark: boolean; onClick: () => void }) {
  return (
    <motion.button
      onClick={onClick}
      whileHover={{ scale: 1.04 }}
      whileTap={{ scale: 0.96 }}
      style={{
        padding: "8px 18px", borderRadius: 50,
        background: active ? (dark ? C.apricot : C.hazelnut) : (dark ? "rgba(255,255,255,0.07)" : C.crema),
        color: active ? (dark ? C.cocoa : C.crema) : (dark ? C.oats : C.hazelnut),
        border: `1px solid ${active ? "transparent" : dark ? "rgba(255,255,255,0.12)" : C.shortbread}`,
        fontFamily: sans, fontSize: "0.78rem", fontWeight: 500,
        cursor: "pointer", transition: "all 0.2s ease",
      }}
    >{children}</motion.button>
  );
}

// ─── BEST SELLERS ─────────────────────────────────────────────────────────────
const sellers = [
  { name: "Classic Strawberry Cake", price: "$48", imgId: "1535141192574-5d4897c12636", rating: 5 },
  { name: "Lemon Mascarpone Tart", price: "$22", imgId: "1611293388250-580b08c4a145", rating: 5 },
  { name: "Almond Croissant", price: "$7", imgId: "1623334044303-241021148842", rating: 5 },
  { name: "Lavender Macaron Box", price: "$28", imgId: "1519665541-b13188b28be9", rating: 5 },
  { name: "Glazed Donut Dozen", price: "$18", imgId: "1527904324834-3bda86da6771", rating: 4 },
  { name: "Pink Velvet Cupcake", price: "$8", imgId: "1599785209796-786432b228bc", rating: 5 },
];

function BestSellers({ dark }: { dark: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  const scroll = (dir: number) => ref.current?.scrollBy({ left: dir * 320, behavior: "smooth" });

  return (
    <section id="best-sellers" style={{ background: dark ? "#2A1F18" : C.crema, padding: "100px 0" }}>
      <div className="max-w-[1440px] mx-auto px-6">
        <SectionLabel dark={dark}>Best Sellers</SectionLabel>
        <div className="flex items-end justify-between mb-10">
          <h2 style={{ fontFamily: serif, fontSize: "clamp(2rem, 4vw, 3rem)", color: dark ? C.crema : C.cocoa, fontWeight: 700 }}>
            Everyone&apos;s <em style={{ fontStyle: "italic", color: dark ? C.apricot : C.peach }}>favorites</em>
          </h2>
          <div className="flex gap-2">
            {[ChevronLeft, ChevronRight].map((Icon, i) => (
              <button key={i} onClick={() => scroll(i === 0 ? -1 : 1)}
                className="w-10 h-10 rounded-full flex items-center justify-center"
                style={{ background: dark ? "rgba(255,255,255,0.1)" : C.oats, border: `1px solid ${dark ? "rgba(255,255,255,0.12)" : C.shortbread}`, cursor: "pointer", color: dark ? C.crema : C.cocoa }}>
                <Icon size={18} />
              </button>
            ))}
          </div>
        </div>
      </div>

      <div ref={ref} className="flex gap-5 overflow-x-auto scrollbar-hide px-6"
        style={{ paddingLeft: "max(24px, calc((100vw - 1440px) / 2 + 24px))", scrollbarWidth: "none" }}>
        {sellers.map((s, i) => (
          <motion.div key={s.name} initial={{ opacity: 0, x: 30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }}
            whileHover={{ y: -8, boxShadow: `0 24px 52px rgba(0,0,0,${dark ? 0.35 : 0.12})` }}
            style={{ flexShrink: 0, width: 260, borderRadius: 24, overflow: "hidden", background: dark ? "#3A2A1E" : C.oats, border: `1px solid ${dark ? "rgba(255,255,255,0.07)" : C.shortbread}`, boxShadow: `0 4px 20px rgba(0,0,0,${dark ? 0.2 : 0.06})`, cursor: "pointer" }}>
            <div style={{ height: 200, overflow: "hidden" }}>
              <img src={img(s.imgId, 300, 220)} alt={s.name} className="w-full h-full object-cover" style={{ transition: "transform 0.4s" }} />
            </div>
            <div style={{ padding: "16px 18px 20px" }}>
              <div className="flex gap-1 mb-2">
                {Array.from({ length: 5 }).map((_, j) => <Star key={j} size={10} fill={j < s.rating ? C.apricot : "none"} color={j < s.rating ? C.apricot : C.shortbread} />)}
              </div>
              <h3 style={{ fontFamily: serif, fontSize: "0.98rem", fontWeight: 700, color: dark ? C.crema : C.cocoa, marginBottom: 8 }}>{s.name}</h3>
              <div className="flex items-center justify-between">
                <span style={{ fontFamily: serif, fontSize: "1.15rem", fontWeight: 700, color: dark ? C.apricot : C.peach }}>{s.price}</span>
                <button style={{ fontFamily: sans, fontSize: "0.7rem", fontWeight: 600, color: dark ? C.apricot : C.hazelnut, background: "none", border: "none", cursor: "pointer" }}>+ Cart</button>
              </div>
            </div>
          </motion.div>
        ))}
        <div style={{ width: 24, flexShrink: 0 }} />
      </div>
    </section>
  );
}

// ─── BAKERY STORY ─────────────────────────────────────────────────────────────
const story = [
  { year: "2008", title: "A family kitchen", desc: "It all began in a tiny kitchen with one KitchenAid mixer, a handful of cherished recipes, and an abundance of love." },
  { year: "2012", title: "Our first bakery", desc: "The first Whisk & Wonder opened its wooden door on Rue des Fleurs — a cozy 400 sq ft of warm light and fresh pastry." },
  { year: "2016", title: "1,000 happy customers", desc: "Word spread faster than frosting on a warm cake. Our regulars became family; our recipes became legend." },
  { year: "2019", title: "Award-winning recipes", desc: "Three consecutive gold medals at the National Patisserie Championships confirmed what our customers already knew." },
  { year: "2024", title: "Luxury dessert boutique", desc: "Today, Whisk & Wonder is a destination — a place where every visit feels like stepping into a sweet, magical story." },
];

function BakeryStory({ dark }: { dark: boolean }) {
  return (
    <section id="our-story" style={{ background: dark ? "#221810" : C.oats, padding: "100px 24px" }}>
      <div className="max-w-[900px] mx-auto">
        <SectionLabel dark={dark}>Our Story</SectionLabel>
        <h2 style={{ fontFamily: serif, fontSize: "clamp(2rem, 4vw, 3rem)", color: dark ? C.crema : C.cocoa, fontWeight: 700, marginBottom: "4rem" }}>
          Baked with <em style={{ fontStyle: "italic", color: dark ? C.apricot : C.peach }}>love</em> since 2008
        </h2>

        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-[18px] md:left-1/2 top-0 bottom-0" style={{ width: 2, background: `linear-gradient(180deg, ${C.peach}, ${C.lilac})`, transform: "translateX(-50%)" }} />

          <div className="flex flex-col gap-12">
            {story.map((s, i) => (
              <motion.div key={s.year}
                initial={{ opacity: 0, x: i % 2 === 0 ? -30 : 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.55 }}
                className={`relative flex ${i % 2 === 0 ? "md:justify-start" : "md:justify-end"} pl-12 md:pl-0`}>

                {/* Dot */}
                <div className="absolute left-0 md:left-1/2 top-2"
                  style={{ width: 36, height: 36, borderRadius: "50%", background: i % 2 === 0 ? C.peach : C.lilac, border: `3px solid ${dark ? "#221810" : C.oats}`, transform: "translateX(-50%)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1 }}>
                  <span style={{ fontSize: "0.9rem" }}>✦</span>
                </div>

                <div style={{
                  width: "100%", maxWidth: "calc(50% - 40px)",
                  background: dark ? "#3A2A1E" : C.crema,
                  borderRadius: 20, padding: "24px 28px",
                  border: `1px solid ${dark ? "rgba(255,255,255,0.07)" : C.shortbread}`,
                  boxShadow: `0 6px 24px rgba(0,0,0,${dark ? 0.2 : 0.06})`,
                }}>
                  <span style={{ fontFamily: sans, fontSize: "0.68rem", fontWeight: 700, color: dark ? C.apricot : C.peach, letterSpacing: "0.16em" }}>{s.year}</span>
                  <h3 style={{ fontFamily: serif, fontSize: "1.25rem", fontWeight: 700, color: dark ? C.crema : C.cocoa, margin: "6px 0 10px" }}>{s.title}</h3>
                  <p style={{ fontFamily: sans, fontSize: "0.83rem", color: dark ? C.shortbread : C.hazelnut, lineHeight: 1.75, opacity: 0.85 }}>{s.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── REVIEWS ─────────────────────────────────────────────────────────────────
const reviews = [
  { name: "Sophie Laurent", handle: "@sophi_l", text: "I ordered a custom birthday cake and it was beyond anything I imagined. The flavors were incredible — like eating a cloud of happiness.", avatar: "🧑‍🦰", bg: C.lilac },
  { name: "Marcus Chen", handle: "@m_chen", text: "The croissants changed my life. I drive 40 minutes every Saturday morning just for a bag of them. Worth every mile.", avatar: "👨‍🦱", bg: C.mint },
  { name: "Isabella Rossi", handle: "@bella.r", text: "Whisk & Wonder is pure magic. The macaron box I gifted my mum made her cry happy tears. That says everything.", avatar: "👩‍🦳", bg: C.apricot },
  { name: "James Park", handle: "@jpark_eats", text: "Never knew a bakery could feel like a sanctuary. The ambiance, the smell, the service — it all feels like a warm hug.", avatar: "🧑‍🦲", bg: C.shortbread },
];

function ReviewsSection({ dark }: { dark: boolean }) {
  return (
    <section style={{ background: dark ? "#2A1F18" : C.crema, padding: "100px 24px" }}>
      <div className="max-w-[1440px] mx-auto">
        <SectionLabel dark={dark}>Reviews</SectionLabel>
        <h2 style={{ fontFamily: serif, fontSize: "clamp(2rem, 4vw, 3rem)", color: dark ? C.crema : C.cocoa, fontWeight: 700, marginBottom: "3.5rem" }}>
          Stories from our <em style={{ fontStyle: "italic", color: dark ? C.apricot : C.peach }}>community</em>
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6">
          {reviews.map((r, i) => (
            <motion.div key={r.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ y: -8 }}
              style={{
                background: dark ? "#3A2A1E" : C.crema,
                borderRadius: 24, padding: "28px 26px",
                border: `1px solid ${dark ? "rgba(255,255,255,0.07)" : C.shortbread}`,
                boxShadow: `0 8px 30px rgba(0,0,0,${dark ? 0.2 : 0.07})`,
                position: "relative",
              }}>
              {/* Color accent bar */}
              <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 4, background: r.bg, borderRadius: "24px 24px 0 0" }} />

              <div className="flex items-center gap-1 mb-4">
                {Array.from({ length: 5 }).map((_, j) => <Star key={j} size={12} fill={C.apricot} color={C.apricot} />)}
              </div>

              <p style={{ fontFamily: sans, fontSize: "0.85rem", color: dark ? C.shortbread : C.hazelnut, lineHeight: 1.8, marginBottom: 20, fontStyle: "italic" }}>
                &ldquo;{r.text}&rdquo;
              </p>

              <div className="flex items-center gap-3">
                <div style={{ width: 40, height: 40, borderRadius: "50%", background: `${r.bg}55`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.4rem" }}>
                  {r.avatar}
                </div>
                <div>
                  <p style={{ fontFamily: sans, fontSize: "0.83rem", fontWeight: 600, color: dark ? C.crema : C.cocoa }}>{r.name}</p>
                  <p style={{ fontFamily: sans, fontSize: "0.7rem", color: dark ? C.shortbread : C.hazelnut, opacity: 0.65 }}>{r.handle}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── GALLERY ─────────────────────────────────────────────────────────────────
const galleryItems = [
  { imgId: "1602663491496-73f07481dbea", caption: "Strawberry Dream Cake", h: 280 },
  { imgId: "1634118520179-0c78b72df69a", caption: "Pastel Macaron Collection", h: 220 },
  { imgId: "1555507036-ab1f4038808a", caption: "Butter Croissants", h: 260 },
  { imgId: "1514517521153-1be72277b32f", caption: "Glazed Donut Tower", h: 220 },
  { imgId: "1519665541-b13188b28be9", caption: "Macaron Stacks", h: 300 },
  { imgId: "1599785209796-786432b228bc", caption: "Rose Cupcake", h: 240 },
  { imgId: "1527904324834-3bda86da6771", caption: "Donut Selection", h: 260 },
  { imgId: "1535141192574-5d4897c12636", caption: "Celebration Cake", h: 220 },
  { imgId: "1623334044303-241021148842", caption: "Morning Pastries", h: 260 },
];

function GallerySection({ dark }: { dark: boolean }) {
  return (
    <section id="gallery" style={{ background: dark ? "#221810" : C.oats, padding: "100px 24px" }}>
      <div className="max-w-[1440px] mx-auto">
        <SectionLabel dark={dark}>Gallery</SectionLabel>
        <h2 style={{ fontFamily: serif, fontSize: "clamp(2rem, 4vw, 3rem)", color: dark ? C.crema : C.cocoa, fontWeight: 700, marginBottom: "3.5rem" }}>
          Beauty in every <em style={{ fontStyle: "italic", color: dark ? C.apricot : C.peach }}>bite</em>
        </h2>
        <div className="columns-2 md:columns-3 gap-5 space-y-5">
          {galleryItems.map((g, i) => (
            <motion.div key={i} className="break-inside-avoid group relative overflow-hidden rounded-2xl cursor-pointer"
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              style={{ height: g.h }}>
              <img src={img(g.imgId, 400, g.h)} alt={g.caption} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                style={{ background: "rgba(74,55,40,0.55)", display: "flex", alignItems: "flex-end", padding: 16 }}>
                <p style={{ fontFamily: sans, fontSize: "0.78rem", fontWeight: 600, color: C.crema, letterSpacing: "0.04em" }}>{g.caption}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── LOYALTY ─────────────────────────────────────────────────────────────────
function LoyaltySection({ dark }: { dark: boolean }) {
  return (
    <section style={{ background: dark ? "#2A1F18" : C.crema, padding: "100px 24px" }}>
      <div className="max-w-[1440px] mx-auto flex flex-col lg:flex-row gap-14 items-center">
        {/* Card visual */}
        <motion.div whileHover={{ rotateY: 8, rotateX: -4, scale: 1.02 }} transition={{ type: "spring", stiffness: 200 }}
          style={{
            flexShrink: 0, width: 360, height: 220, borderRadius: 24,
            background: `linear-gradient(135deg, ${C.hazelnut} 0%, ${C.cocoa} 60%, #2A1008 100%)`,
            padding: "28px 30px", color: C.crema,
            boxShadow: `0 24px 60px rgba(0,0,0,0.4)`,
            position: "relative", overflow: "hidden",
          }}>
          {/* Decorative circles */}
          <div style={{ position: "absolute", top: -40, right: -40, width: 160, height: 160, borderRadius: "50%", background: "rgba(255,255,255,0.06)" }} />
          <div style={{ position: "absolute", bottom: -30, left: -30, width: 120, height: 120, borderRadius: "50%", background: "rgba(255,255,255,0.04)" }} />

          <div className="flex justify-between items-start mb-8">
            <div>
              <p style={{ fontFamily: sans, fontSize: "0.6rem", letterSpacing: "0.24em", opacity: 0.65, fontWeight: 600 }}>WHISK & WONDER</p>
              <p style={{ fontFamily: serif, fontSize: "1.1rem", fontWeight: 700, marginTop: 4 }}>Sweet Rewards Card</p>
            </div>
            <span style={{ fontSize: "2rem" }}>🍰</span>
          </div>
          <div className="flex justify-between items-end">
            <div>
              <p style={{ fontFamily: sans, fontSize: "0.6rem", letterSpacing: "0.1em", opacity: 0.55, fontWeight: 500 }}>MEMBER SINCE</p>
              <p style={{ fontFamily: serif, fontSize: "0.9rem", marginTop: 3 }}>March 2024</p>
            </div>
            <div className="text-right">
              <p style={{ fontFamily: sans, fontSize: "0.6rem", letterSpacing: "0.1em", opacity: 0.55, fontWeight: 500 }}>DESSERT POINTS</p>
              <p style={{ fontFamily: serif, fontSize: "1.5rem", fontWeight: 700, color: C.apricot }}>2,480</p>
            </div>
          </div>
        </motion.div>

        {/* Text */}
        <div>
          <SectionLabel dark={dark}>Loyalty Program</SectionLabel>
          <h2 style={{ fontFamily: serif, fontSize: "clamp(1.8rem, 3.5vw, 2.8rem)", color: dark ? C.crema : C.cocoa, fontWeight: 700, marginBottom: "1rem" }}>
            Earn <em style={{ fontStyle: "italic", color: dark ? C.apricot : C.peach }}>sweet</em> rewards
          </h2>
          <p style={{ fontFamily: sans, fontSize: "0.92rem", color: dark ? C.shortbread : C.hazelnut, lineHeight: 1.8, maxWidth: 480, marginBottom: "2rem", opacity: 0.85 }}>
            Join our loyalty program and earn Dessert Points on every purchase. Redeem them for free treats, exclusive discounts, and early access to seasonal specials.
          </p>
          <div className="grid grid-cols-3 gap-5 mb-8">
            {[["Earn Points", "🛍️", "1 point per $1"], ["Redeem Gifts", "🎁", "100 pts = $5 off"], ["Exclusive Perks", "⭐", "Birthday bonus cake"]].map(([t, e, d]) => (
              <div key={t} style={{ padding: "18px 14px", borderRadius: 18, background: dark ? "rgba(255,255,255,0.06)" : C.oats, border: `1px solid ${dark ? "rgba(255,255,255,0.1)" : C.shortbread}`, textAlign: "center" }}>
                <div style={{ fontSize: "1.6rem", marginBottom: 8 }}>{e}</div>
                <p style={{ fontFamily: sans, fontSize: "0.75rem", fontWeight: 700, color: dark ? C.crema : C.cocoa, marginBottom: 4 }}>{t}</p>
                <p style={{ fontFamily: sans, fontSize: "0.65rem", color: dark ? C.shortbread : C.hazelnut, opacity: 0.7 }}>{d}</p>
              </div>
            ))}
          </div>
          <Btn variant="primary" dark={dark} onClick={() => {}}>
            <Gift size={15} style={{ marginRight: 8, display: "inline" }} />
            Join Sweet Rewards
          </Btn>
        </div>
      </div>
    </section>
  );
}

// ─── NEWSLETTER ───────────────────────────────────────────────────────────────
function NewsletterSection({ dark }: { dark: boolean }) {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);

  return (
    <section style={{ background: dark ? "#221810" : C.oats, padding: "100px 24px" }}>
      <div className="max-w-[680px] mx-auto text-center relative">
        {/* Floating items */}
        {(["🧁", "🍪", "🎂", "🍩"] as const).map((e, i) => {
          const positions = [
            { top: -24, left: "2%" },
            { top: -24, right: "3%" },
            { bottom: -20, left: "8%" },
            { bottom: -20, right: "10%" },
          ][i];
          return (
            <motion.span key={i} className="absolute pointer-events-none select-none"
              style={{ fontSize: "1.7rem", ...positions }}
              animate={{ y: [0, -12, 0], rotate: [0, 9, -9, 0] }}
              transition={{ duration: 4 + i * 0.8, repeat: Infinity, delay: i * 0.5 }}>
              {e}
            </motion.span>
          );
        })}

        <SectionLabel dark={dark}>Newsletter</SectionLabel>
        <h2 style={{ fontFamily: serif, fontSize: "clamp(1.8rem, 3.5vw, 2.8rem)", color: dark ? C.crema : C.cocoa, fontWeight: 700, marginBottom: "1rem" }}>
          Fresh news, delivered <em style={{ fontStyle: "italic", color: dark ? C.apricot : C.peach }}>daily</em>
        </h2>
        <p style={{ fontFamily: sans, fontSize: "0.9rem", color: dark ? C.shortbread : C.hazelnut, lineHeight: 1.75, marginBottom: "2.5rem", opacity: 0.8 }}>
          Subscribe for seasonal menus, exclusive recipes, and first access to our limited edition collections.
        </p>

        {sent ? (
          <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
            style={{ padding: "20px 32px", borderRadius: 60, background: `${C.mint}33`, border: `1px solid ${C.mint}`, display: "inline-flex", alignItems: "center", gap: 10 }}>
            <Check size={18} color={C.mint} />
            <span style={{ fontFamily: sans, fontWeight: 600, color: dark ? C.mint : "#1A4A34", fontSize: "0.9rem" }}>You&apos;re on the list — welcome! 🎉</span>
          </motion.div>
        ) : (
          <form onSubmit={e => { e.preventDefault(); if (email) setSent(true); }}
            className="flex gap-3 max-w-[480px] mx-auto">
            <div className="flex-1 relative">
              <Mail size={16} className="absolute left-4 top-1/2 -translate-y-1/2" style={{ color: dark ? C.shortbread : C.hazelnut, opacity: 0.5 }} />
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="your@email.com"
                required
                style={{
                  width: "100%", padding: "14px 18px 14px 42px", borderRadius: 50,
                  background: dark ? "rgba(255,255,255,0.08)" : C.crema,
                  border: `1px solid ${dark ? "rgba(255,255,255,0.15)" : C.shortbread}`,
                  fontFamily: sans, fontSize: "0.88rem", color: dark ? C.crema : C.cocoa, outline: "none",
                }}
              />
            </div>
            <Btn variant="primary" dark={dark}>Subscribe</Btn>
          </form>
        )}
        <p style={{ fontFamily: sans, fontSize: "0.7rem", color: dark ? C.shortbread : C.hazelnut, marginTop: 14, opacity: 0.6 }}>
          No spam, ever. Unsubscribe in one click.
        </p>
      </div>
    </section>
  );
}

// ─── FOOTER ───────────────────────────────────────────────────────────────────
function Footer({ dark }: { dark: boolean }) {
  return (
    <footer style={{ background: dark ? "#1A1008" : C.cocoa, padding: "72px 24px 36px", color: C.crema }}>
      <div className="max-w-[1440px] mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <span style={{ fontSize: "1.8rem" }}>🥐</span>
              <h3 style={{ fontFamily: serif, fontSize: "1.5rem", fontWeight: 700, color: C.apricot }}>Whisk & Wonder</h3>
            </div>
            <p style={{ fontFamily: sans, fontSize: "0.85rem", color: C.shortbread, lineHeight: 1.8, opacity: 0.75, maxWidth: 320 }}>
              A magical place where every pastry is a love letter, every cake a celebration, and every visit an unforgettable memory.
            </p>
            {/* Sleeping cat + coffee */}
            <div className="flex items-center gap-4 mt-6">
              <motion.span animate={{ scale: [1, 1.05, 1] }} transition={{ duration: 3, repeat: Infinity }} style={{ fontSize: "1.8rem" }}>😺</motion.span>
              <div>
                <motion.span style={{ fontSize: "1.5rem" }}>☕</motion.span>
                <motion.div style={{ width: 2, height: 16, background: "rgba(255,255,255,0.3)", marginLeft: 12, marginTop: -8, borderRadius: 2 }}
                  animate={{ scaleY: [1, 0.5, 1], opacity: [1, 0.3, 1] }} transition={{ duration: 2, repeat: Infinity }} />
              </div>
              <span style={{ fontFamily: sans, fontSize: "0.75rem", color: C.shortbread, opacity: 0.6 }}>Still baking with love ✦</span>
            </div>
          </div>

          {/* Quick links */}
          <div>
            <h4 style={{ fontFamily: sans, fontSize: "0.7rem", fontWeight: 700, color: C.apricot, letterSpacing: "0.22em", marginBottom: 20 }}>QUICK LINKS</h4>
            {["Menu", "Custom Cakes", "Best Sellers", "Our Story", "Gallery", "Contact"].map(l => (
              <div key={l} style={{ marginBottom: 12 }}>
                <a href="#" style={{ fontFamily: sans, fontSize: "0.85rem", color: C.shortbread, opacity: 0.75, textDecoration: "none", transition: "opacity 0.2s" }}
                  onMouseEnter={e => (e.currentTarget.style.opacity = "1")}
                  onMouseLeave={e => (e.currentTarget.style.opacity = "0.75")}>{l}</a>
              </div>
            ))}
          </div>

          {/* Contact */}
          <div>
            <h4 style={{ fontFamily: sans, fontSize: "0.7rem", fontWeight: 700, color: C.apricot, letterSpacing: "0.22em", marginBottom: 20 }}>FIND US</h4>
            <div className="flex flex-col gap-4">
              <div className="flex items-start gap-3">
                <MapPin size={15} style={{ color: C.peach, marginTop: 2, flexShrink: 0 }} />
                <p style={{ fontFamily: sans, fontSize: "0.83rem", color: C.shortbread, opacity: 0.75, lineHeight: 1.6 }}>12 Rue des Fleurs<br />Paris, 75001</p>
              </div>
              <div className="flex items-center gap-3">
                <Coffee size={15} style={{ color: C.peach, flexShrink: 0 }} />
                <p style={{ fontFamily: sans, fontSize: "0.83rem", color: C.shortbread, opacity: 0.75 }}>Tue–Sun: 7am – 7pm</p>
              </div>
              <div className="flex items-center gap-3">
                <Mail size={15} style={{ color: C.peach, flexShrink: 0 }} />
                <p style={{ fontFamily: sans, fontSize: "0.83rem", color: C.shortbread, opacity: 0.75 }}>hello@whiskandwonder.com</p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div style={{ borderTop: "1px solid rgba(255,255,255,0.1)", paddingTop: 28, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12 }}>
          <p style={{ fontFamily: sans, fontSize: "0.75rem", color: C.shortbread, opacity: 0.5 }}>
            © 2024 Whisk & Wonder. Made with 🧁 and a little magic.
          </p>
          <div className="flex items-center gap-2">
            {/* Moon decoration */}
            <span style={{ fontSize: "1.1rem", marginRight: 8 }}>🌙</span>
            {["✦", "⭐", "✦"].map((s, i) => (
              <motion.span key={i} style={{ fontSize: "0.7rem", color: C.lavender }}
                animate={{ opacity: [0.3, 1, 0.3] }} transition={{ duration: 2, repeat: Infinity, delay: i * 0.5 }}>{s}</motion.span>
            ))}
          </div>
          <p style={{ fontFamily: sans, fontSize: "0.75rem", color: C.shortbread, opacity: 0.5 }}>
            Privacy · Terms · Sitemap
          </p>
        </div>
      </div>
    </footer>
  );
}

// ─── SECTION LABEL ────────────────────────────────────────────────────────────
function SectionLabel({ children, dark }: { children: React.ReactNode; dark: boolean }) {
  return (
    <p style={{ fontFamily: sans, fontSize: "0.68rem", fontWeight: 700, color: dark ? C.apricot : C.peach, letterSpacing: "0.28em", marginBottom: 14, display: "flex", alignItems: "center", gap: 8 }}>
      <span>✦</span> {children} <span>✦</span>
    </p>
  );
}

// ─── APP ROOT ─────────────────────────────────────────────────────────────────
export default function App() {
  const [stage, setStage] = useState<Stage>("loading");
  const [dark, setDark] = useState(false);
  const [cartCount, setCartCount] = useState(0);

  useEffect(() => {
    if (dark) document.documentElement.classList.add("dark");
    else document.documentElement.classList.remove("dark");
  }, [dark]);

  return (
    <div style={{ fontFamily: sans, minHeight: "100vh" }}>
      <AnimatePresence mode="wait">
        {stage === "loading" && (
          <LoadingScreen key="loading" onDone={() => setStage("entrance")} />
        )}
        {stage === "entrance" && (
          <EntranceScreen key="entrance" onEnter={() => setStage("main")} dark={dark} />
        )}
      </AnimatePresence>

      {stage === "main" && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.6 }}>
          <Navbar dark={dark} setDark={setDark} cartCount={cartCount} />
          <HeroSection dark={dark} />
          <CategoriesSection dark={dark} />
          <FeaturedProducts dark={dark} />
          <CakeBuilderSection dark={dark} />
          <BestSellers dark={dark} />
          <BakeryStory dark={dark} />
          <ReviewsSection dark={dark} />
          <GallerySection dark={dark} />
          <LoyaltySection dark={dark} />
          <NewsletterSection dark={dark} />
          <Footer dark={dark} />
        </motion.div>
      )}
    </div>
  );
}
